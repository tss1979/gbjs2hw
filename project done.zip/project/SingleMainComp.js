Vue.component('mainspproduct', {
    data() {
        return {
            singlepageproduct: {
                quantity: 1,
                id_product: 139,
                price: 561,
                img: 'img/mainpic.jpg'
            },
            products: [],
        }
    },

    template: `<div class="wcolection">
                <div class="flexwcolection">
                    <div class="wcolectiontext"><a class="tophead" href="#">WOMEN COLLECTION</a></div>
                    <div class="wcolectiontext-2">Moschino Cheap And Chic</div>
                    <div class="wcolectiontext-3">Compellingly actualize fully researched processes before proactive outsourcing. Progressively syndicate collaborative architectures before cutting-edge services. Completely visualize parallel core competencies rather than exceptional portals.</div>
                    <div class="mat">
                        <p class="material">MATERIAL: <span class="cotton"> COTTON</span></p>
                        <p class="material">DESIGNER: <span class="cotton"> BINBURHAN</span></p>
                    </div>
                    <p class="singlepageprice">$561</p>
                    <form class="choose">
                        <p class="choosediv">
                            <label class="colorlable" for="color">CHOOSE COLOR</label><br>
                            <select name="color" id="color" class="color">
                                <option value="#">Red</option>
                                <option value="#">Green</option>
                                <option value="#">White</option>
                                <option value="#">BLUE</option>
                            </select>
                        </p>
                        <p>
                            <label class="colorlable" for="size">SIZE</label><br>
                            <select name="color" id="size" class="color">
                                <option value="#">XS</option>
                                <option value="#">S</option>
                                <option value="#">M</option>
                                <option value="#">L</option>
                                <option value="#">XL</option>
                            </select>
                        </p>
                        <p>
                            <label class="colorlable" for="quantity">QUANTITY</label><br>
                            <input v-model.lazy="singlepageproduct.quantity" id="quantity" class="color qun" type="text">
                        </p>
                        <div class="submitsingle" @click="$root.$refs.cart.addProduct(singlepageproduct)">
                            <input class="cart" type="submit" value="Add to Cart">
                            <img class="imgcart" src="img/cartred.svg" alt="cart">
                        </div>
                    </form>
                </div>
            </div>`
});