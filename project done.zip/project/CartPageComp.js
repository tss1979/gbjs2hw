Vue.component('cartpage', {
    data() {
        return {
            cartItems: [],
            showCart: false,

        }
    },

    computed: {
        totalAmount() {
            let result = 0;
            for (let el of this.cartItems) {
                result += el.price * el.quantity;
            }
            return result
        }
    },

    methods: {

        remove(product) {
            if (product.quantity > 1) {
                this.totalAmount -= +product.price;
                product.quantity--;
                
            } else {
                this.totalAmount -= +product.price;
                for (let el of this.cartItems) {
                    if (el.id_product === product.id_product) {
                        this.cartItems.splice(this.cartItems.indexOf(el), 1);
                    }
                }
            }
            this.$root.$refs.cart.cartItems = [];
            this.$root.$refs.cart.totalAmount = this.totalAmount;
               for(let el of this.cartItems) {
                  this.$root.$refs.cart.cartItems.push(el); 
               }
        },

        clear() {
            this.totalAmount = 0;
            this.cartItems = [];
            this.$root.$refs.cart.cartItems = [];
            this.$root.$refs.cart.totalAmount = 0;
        }
    },
    mounted() {
        this.$parent.getJson(`https://raw.githubusercontent.com/tss1979/gbjs2hw/master/cartProducts.json`)
            .then(data => {
                for (let el of data.contents) {
                    this.cartItems.push(el);
                    this.totalAmount += el.price;
                }
            });
    },

    template: `<div>
                   <div class="tablehead">
                      <h3 class="table-h3">Product Details</h3>
                      <h3 class="table-h3">unite Price</h3>
                      <h3 class="table-h3">Quantity</h3>
                      <h3 class="table-h3">shipping</h3>
                      <h3 class="table-h3">Subtotal</h3>
                      <h3 class="table-h3">ACTION</h3>
                   </div>
                   <div class="allproductcart">
                         <cartpage-item v-for="product of cartItems"
                                    :key="product.id_product"
                                    :img="product.img"
                                    :product="product"
                                    @remove="remove">
                          </cartpage-item>
                    </div>
                    <div class="cartform">
                      <form class="cartform" action="#">
                            <div class="towbotons">
                            <button class="buttoncart" @click="clear">CLEAR SHOPPING CART</button>
                            <button class="buttoncart"><a class="btna" href="index.html">CONTINUE SHOPPING</a></button>
                            </div>
                            <div class="freeblocks">
                               <div class="cartshipadd ">
                                   <h3 class="shipaddress-h3">Shipping Adress</h3>
                                   <select class="shipaddress-select" name="country" id="country" size="3">
                                   <option id="Bangladesh" class="sectioncart-opt" value="Bangladesh">Bangladesh</option>
                                   <option id="Russia" class="sectioncart-opt" value="Russia">Russia</option>
                                   <option id="USA" class="sectioncart-opt" value="USA">USA</option>
                                   </select>
                                   <input class="cartinfoinput" type="text" placeholder="State">
                                   <input class="cartinfoinput" type="text" placeholder="Postcode / Zip">
                                   <input class="getcart" type="submit" value="get a quote">
                                </div>
                                <div class="cartshipadd-2">
                                   <h3 class="shipaddress-h3">coupon discount</h3>
                                   <p class="coupon">Enter your coupon code if you have one</p>
                                   <input class="cartinfoinput" type="text" placeholder="Coupon code">
                                   <input class="applycoupon" type="submit" value="Apply coupon">
                                </div>
                                <div class="cartshipadd-3">
                                  <p class="cartshipadd-3-p">Sub total <span class="cartshipadd-3-p_right">{{totalAmount}}</span> </p>
                                  <p class="cartshipadd-3-p_grand">GRAND TOTAL <span class="cartshipadd-3-p_right_red">{{totalAmount}}</span></p>
                                  <a class="proced tpr" type="submit" href="checkout.html" >proceed to checkout</a>
                               </div>
                           </div>
                      </form>
                   </div>
            </div>`
});

Vue.component('cartpage-item', {
    props: ['product', 'img'],
    template: `<div class="tableproduct">
                     <img class="photocart" :src="img" alt="photo-1">
                     <div class="cartphototext">
                       <h3 class="cartphototext-h3">{{product.product_name}}</h3>
                       <p class="cartphototext-p">Color: <span class="cartspan"> Red </span> <br>
                        Size: <span class="cartspan"> Xll</span> </p>
                     </div>
                    <div class="pricecart">
                       <p class="cartprice">{{product.price}}</p>
                   </div>
                   <input  id="quantity" class="quantitycart style" 
     v-model.lazy="product.quantity" @change="$root.$refs.cart.change(product)">
                   <div class="shippingcart">
                      <p class="cartprice">FREE</p>
                   </div>
                   <div class="shippingcart">
                      <p class="cartprice subtotal">{{product.price*product.quantity}}</p>
                   </div>
                   <div class="cancel canmar">
                     <i class="fas fa-times-circle cancel__link" @click="$emit('remove', product)"></i>
                   </div>
              </div>`

});
