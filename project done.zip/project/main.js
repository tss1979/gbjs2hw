let app = new Vue({
    el: '#app',
    data: {
        showCart: false,
        userSearch: '',
        filtered: [],
        cartItems: [],
        products: [],
    },
    methods: {
        getJson(url) {
            return fetch(url)
                .then(result => result.json())
                .catch(error => {
                    this.$refs.error.setError(error);
                    console.log(error)
                })
        },

        addProduct(product) {
            let find = this.cartItems.find(el => el.id_product === product.id_product);
            if (find) {
                find.quantity++;
            } else {
                let prod = Object.assign({
                    quantity: 1
                }, product);
                this.cartItems.push(prod);
            }
        }
    }

});
