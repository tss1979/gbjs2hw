Vue.component('singlepageproducts', {
    data() {
        return {
            filtered: [],
            products: [],
        }
    },
    mounted() {
        this.$parent.getJson('https://raw.githubusercontent.com/tss1979/gbjs2hw/master/singlepage.json')
            .then(data => {
                for (let el of data.contents) {
                    this.products.push(el);
                    this.filtered.push(el);
                }
            });
    },
    methods: {
        filter(value) {
            let regexp = new RegExp(value, 'i');
            this.filtered = this.products.filter(el => regexp.test(el.product_name));
        }
    },
    template: `<div class="container productflex">
                  <spproduct v-for="product of filtered" 
                  :key="product.id_product"
                  :img="product.img"
                  :product="product">
                  </spproduct>
              </div>`

})

Vue.component('spproduct', {
    props: ['product', 'img'],
    template: `<div class = "product" @click="$root.$refs.cart.addProduct(product)">
                     <a href = "#"><img class="productimage-45" :src = 'img' alt = "porduct1" ></a>
                         <div class = "textphoto" >
                           <a class = "tp-1" href = "#">{{ product.product_name }}</a>
                           <p class = "tp-2" >$ {{product.price}}</p> 
                         </div> 
                           <div class="button_add" @click="$root.$refs.cart.addProduct(product)">
                           <img class="btn_img" src = "img/cart.svg" alt = "cart">
                          <p class="p_add" > add to cart </p>
                          </div> 

                   </div>`
});
