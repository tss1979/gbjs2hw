Vue.component('list', {
    data() {
        return {
            showList: true,
            showList2: false,
            showList3: false,
        }
    },

    template: `<div>
                    <div class="headleftside"  @click="showList = !showList">
                    <h3 class="mannav-h3">CATEGORY </h3>
                    <img v-if="showList" class="redarrow" src="img/redarrow.png" alt="redarrow">
                    <img v-else class="redarrow" src="img/grayarrow.png" alt="redarrow">
                    </div>
                    <ul class="leftsideul" v-show="showList">
                       <li><a class="left-link" href="#">Accessories</a></li>
                       <li><a class="left-link" href="#">Bags</a></li>
                       <li><a class="left-link" href="#">Denim</a></li>
                       <li><a class="left-link" href="#">Hoodies & Sweatshirts</a></li>
                       <li><a class="left-link" href="#">Jackets & Coats</a></li>
                       <li><a class="left-link" href="#">Pants</a></li>
                       <li><a class="left-link" href="#">Polos</a></li>
                       <li><a class="left-link" href="#">Shirts</a></li>
                       <li><a class="left-link" href="#">Shoes</a></li>
                       <li><a class="left-link" href="#">Shorts</a></li>
                       <li><a class="left-link" href="#">Sweaters & Knits</a></li>
                       <li><a class="left-link" href="#">T-Shirts</a></li>
                       <li><a class="left-link" href="#">Tanks</a></li>
                   </ul>
                   <div class="headleftside"  @click="showList2 = !showList2">
                    <h3 class="mannav-h3">BRAND</h3>
                    <img v-if="showList2" class="redarrow" src="img/redarrow.png" alt="redarrow">
                    <img v-else class="redarrow" src="img/grayarrow.png" alt="redarrow">
                    </div>
                    <ul class="leftsideul" v-show="showList2">
                       <li><a class="left-link" href="#">Mango</a></li>
                       <li><a class="left-link" href="#">Redbox Zane</a></li>
                       <li><a class="left-link" href="#">Glory</a></li>
                   </ul>
                   <div class="headleftside"  @click="showList3 = !showList3">
                    <h3 class="mannav-h3">DESIGNER</h3>
                   <img v-if="showList3" class="redarrow" src="img/redarrow.png" alt="redarrow">
                    <img v-else class="redarrow" src="img/grayarrow.png" alt="redarrow">
                    </div>
                    <ul class="leftsideul" v-show="showList3">
                       <li><a class="left-link" href="#">Binburhan</a></li>
                       <li><a class="left-link" href="#">One Plus</a></li>
                       <li><a class="left-link" href="#">Valentino</a></li>
                   </ul>
              </div>`
});
