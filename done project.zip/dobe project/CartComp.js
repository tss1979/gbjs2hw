Vue.component('cart', {
    data() {
        return {
            cartItems: [],
            showCart: false,
            totalAmount: 0,
            quantity: []
        }
    },
    methods: {
        addProduct(product) {
            let find = this.cartItems.find(el => el.id_product === product.id_product);
            if (find) {
                this.totalAmount += find.price;
                find.quantity++;
            } else {
                let prod = Object.assign({
                    quantity: 1
                }, product);
                this.cartItems.push(prod);
                this.totalAmount += product.price * prod.quantity;
            }
        },

        remove(product) {
            if (product.quantity > 1) {
                this.totalAmount -= +product.price;
                product.quantity--;

            } else {
                this.totalAmount -= +product.price;
                for (let el of this.cartItems) {
                    if (el.id_product === product.id_product) {
                        this.cartItems.splice(this.cartItems.indexOf(el), 1);
                    }
                }
            }
            this.$root.$refs.cartpage.update();
        },
        
        change() {
            this.cartItems = [];
            this.totalAmount = this.$root.$refs.cartpage.totalAmount; 
              for(let el of this.$root.$refs.cartpage.cartItems) {
                this.cartItems.push(el); 
              }
        },
        
        update() {
        this.cartItems = [];
            this.totalAmount = this.$root.$refs.cartpage.totalAmount;
               for(let el of this.$root.$refs.cartpage.cartItems) {
                  this.cartItems.push(el); 
               }
        }
    },

    mounted() {
        this.$parent.getJson(`https://raw.githubusercontent.com/tss1979/gbjs2hw/master/cartProducts.json`)
            .then(data => {
                for (let el of data.contents) {
                    this.cartItems.push(el);
                    this.totalAmount += el.price;
                }
            });
    },

    template: `<div>
               <a class="cart-1" href="#"><img src="img/basket.svg" alt="basket" @click="showCart = !showCart"></a>
                   <div class="index_cart" v-show="showCart">
                         <cart-item v-for="product of cartItems"
                                    :key="product.id_product"
                                    :img="product.img"
                                    :product="product"
                                    @remove="remove">
                          </cart-item>
                         <div class="indexcarttotal">
                         <p>TOTAL</p>
                         <p>$ {{totalAmount}}</p>
                         </div>
                         <a href="checkout.html"><div class="checkout" @click="showCart = !showCart">Checkout</div></a>
                        <a class="acart" href="shopingcart.html"><div class="checkout">Go to cart</div></a>
                         
                  </div>
              </div>`
});

Vue.component('cart-item', {
    props: ['product', 'img'],
    template: `<div class="index_cart_item">
                   <img class="indexcartimg" :src="img" alt="cartimg">
                       <div class="index_cart_text">
                       <p class="indexcartname">{{product.product_name}}</p>
       <img src="img/stars.png" class="stars" alt="stars">
                       <p class="indexcartprice">{{product.quantity}} x $ {{product.price}}</p>
                       </div>
                  <i class="fas fa-times-circle del" @click="$emit('remove', product)"></i>
                  </div>`

});
